import math, time
import Utility
from Utility import *
from kivy.animation import Animation
from Sprite import Sprite, gSpriteMgr
from Particle import gFxMgr
from ResourceMgr import gResMgr

from Constants import *
import GameFrame
import Stage

class CharacterMgr(Singleton):
  def __init__(self):
    self.characters = []
    self.monsters = []
    self.player = None
    self.stageMgr = None
  
  def reset(self, parentWidget):
    self.monsters = []
    self.characters = []
    self.stageMgr = Stage.gStageMgr
    
    # add player
    playerIndex = 4 # A bee
    props = gResMgr.getProperty("character")
    prop = props.properties[playerIndex]
    pos = (CHARACTER_SIZE[0], random.uniform(0, H))
    gPlayer.init(pos, CHARACTER_SIZE, prop)
    gPlayer.reset()
    parentWidget.add_widget(gPlayer.getSprite())
    self.player = gPlayer
    # bind input button
    GameFrame.gGameFrame.buttonBind(self.player.setMoveLeft, self.player.setMoveRight)
    self.characters.append(self.player)
      
    # add monster
    count = self.stageMgr.getEnemyCount()
    for i in range(count):
      n = playerIndex
      while n == playerIndex:
        n = random.randrange(0, len(props.properties))
      prop = props.properties[n]
      pos = (random.uniform(SEARCH_RANGE * 1.5, W), random.uniform(0, H)) 
      monster = Monster(pos, CHARACTER_SIZE, prop)
      monster.reset()
      parentWidget.add_widget(monster.getSprite())
      self.monsters.append(monster)
      self.characters.append(monster)
      
  def getMonsters(self):
    return self.monsters
  
  def getCharacters(self):
    return self.characters
  
  def update(self):
    for character in self.characters:
      character.update()
    
    # check collide
    hitList = set()
    for i, A in enumerate(self.characters):
      posA = A.getPos()
      vA = A.getVelocity()
      lA = getDist(vA)
      nA = normalize(vA)
      for B in self.characters[i+1:]:
        posB = B.getPos()
        dist = getDist(posA, posB)
        if dist < 100.0:
          v = normalize(sub(posA, posB))
          vB = B.getVelocity()
          lB = getDist(vB)
          nB = normalize(vB)
          d = -dot(v, nA)
          isHit = False
          if d > 0.0:
            isHit = True
            A.setVelocity(*sub(A.getVelocity(), vA))
            B.setVelocity(*add(B.getVelocity(), mul(vA, d)))
            rV = mul(v, dot(v, mul(nA, -1.0)))
            rV = sub(mul(rV, 2.0), mul(nA, -1.0))
            rV = mul(normalize(rV), lA * (1.0-d))
            A.setVelocity(*add(A.getVelocity(), rV))
          d = dot(v, nB)
          if d > 0.0:
            isHit = True
            A.setVelocity(*add(A.getVelocity(), mul(vB, d)))
            B.setVelocity(*sub(B.getVelocity(), vB))
            v = mul(v, -1.0)
            rV = mul(v, dot(v, mul(nB, -1.0)))
            rV = sub(mul(rV, 2.0), mul(nB, -1.0)) 
            rV = mul(normalize(rV), lB * (1.0-d))
            B.setVelocity(*add(B.getVelocity(), rV))
          # check damage
          if isHit:
            if abs(v[0]) < DAMAGE_ANGLE:
              if posA[1] > posB[1]:
                hitList.add(B)
              else:
                hitList.add(A)
          # set damage
          for hitted in hitList:
            hitted.setDamage()
            if hitted.isDead and hitted in self.characters:
              self.characters.remove(hitted)
  
class BaseCharacter():
  def __init__(self, pos, size, prop):
    self.prop = prop
    self.maxHp = MAXHP
    self.hp = self.maxHp
    self.damageTime = 0.0
    self.isHitted = False
    self.isDead = False
    self.isMoveLeft = False
    self.isMoveRight = False
    self.target = None
    self.sprite = Sprite(pos=pos, size=size, gravity=GRAVITY, friction=FRICTION, elastin=ELASTIN, collision=True, collisionSpace=WORLD_REGION, texture=prop["image"].texture)
  
  def reset(self):
    self.isHitted = False
    self.target = None
    self.sprite.color.rgba = (1,1,1,1)
    self.isDead = False
    self.isMoveLeft = False
    self.isMoveRight = False
    self.hp = self.maxHp
  
  def destroy(self):
    pass
    
  def getPos(self):
    return self.sprite.getPos()
    
  def getVelocity(self):
    return self.sprite.getVelocity()
  
  def setVelocity(self, vx, vy):
    self.sprite.setVelocity(vx, vy)
    
  def setMoveLeft(self, isMove):
    self.isMoveLeft = isMove
    
  def setMoveRight(self, isMove):
    self.isMoveRight = isMove
    
  def getSprite(self):
    return self.sprite 
  
  def update(self):
    if self.isDead:
      return
      
    frameTime = Utility.getFrameTime()
      
    if self.isHitted:
      self.updateHit()
        
    # set jump
    if self.sprite.isGround:
      self.sprite.setVelocity(self.sprite.getVelocity()[0], JUMP)
      
    if self.isMoveLeft:
      vx, vy = self.getVelocity()
      if vy < 0.0:
        vy -= MOVE_ACCELERATE * frameTime
      if vx > -MAX_MOVE_SPEED:
        vx -= MOVE_ACCELERATE * frameTime
        if vx < -MAX_MOVE_SPEED:
          vx = -MAX_MOVE_SPEED
      self.setVelocity(vx, vy)
    elif self.isMoveRight:
      vx, vy = self.getVelocity()
      if vy < 0.0:
        vy -= MOVE_ACCELERATE * frameTime
      if vx < MAX_MOVE_SPEED:
        vx += MOVE_ACCELERATE * frameTime
        if vx > MAX_MOVE_SPEED:
          vx = MAX_MOVE_SPEED
      self.setVelocity(vx, vy)
    if not self.isMoveLeft and not self.isMoveRight:
      vx, vy = self.getVelocity()
      if vx != 0.0:
        if vx > 0.0:
          vx -= MOVE_ACCELERATE * frameTime
          if vx < 0.0:
            vx = 0.0
        else:
          vx += MOVE_ACCELERATE * frameTime
          if vx > 0.0:
            vx = 0.0
        self.setVelocity(vx, vy)
  
  def updateHit(self):
    if self.damageTime > DAMAGE_TIME:
      self.isHitted = False
      self.sprite.color.rgba = (1,1,1,1)
    else:
      self.damageTime += getFrameTime()
      bright = 1.0 + DAMAGE_BRIGHT * abs(math.sin(self.damageTime * DAMAGE_SPEED))
      self.sprite.color.rgba = (bright, bright, bright, bright - 0.7)
    
  def setDamage(self, n=1):
    if self.isHitted:
      return
    
    gFxMgr.get_emitter(PARTICLE_HIT).play_particle_with(self.sprite, True)
    self.isHitted = True
    self.damageTime = 0.0
    self.hp -= n
    if self.hp <= 0:
      self.hp = 0
      self.setDead()
  
  def setDead(self):
    self.isDead = True
    if self.sprite.parent:
      self.sprite.parent.remove_widget(self.sprite)

 
class Player(BaseCharacter, Singleton):
  def __init__(self):
    pass
    
  def init(self, pos, size, prop):
    BaseCharacter.__init__(self, pos, size, prop)
    

class Monster(BaseCharacter):
  def update(self):
    if self.isDead:
      return
      
    # updat  move
    BaseCharacter.update(self)
    
    # update ai
    if self.target:
      dx = self.getPos()[0] - self.target.getPos()[0]  
      dy = self.getPos()[1] - self.target.getPos()[1]
      # attack
      if abs(dx) > ATTACK_RANGE:
        self.setMoveLeft(dx > 0.0)
        self.setMoveRight(not self.isMoveLeft)
      # evade
      elif abs(dx) < EVADE_RANGE and dy < 0.0:
        self.setMoveLeft(dx < 0.0)
        self.setMoveRight(not self.isMoveLeft)
      # stop
      else:
        self.setMoveLeft(False)
        self.setMoveRight(False)
    else:
      # search target
      dx = self.getPos()[0] - gPlayer.getPos()[0]
      if abs(dx) < SEARCH_RANGE:
        self.target = gPlayer


gCharacterMgr = CharacterMgr.instance()
gPlayer = Player()