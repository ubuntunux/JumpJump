from collections import namedtuple
import os

from toast import toast
from Utility import *
from FileBrowser import FileBrowser
from ResourceMgr import *
    

class ActorProperty:
  labelWidth = kivy.metrics.dp(100)
  labelHeight = kivy.metrics.dp(30)
  padding = kivy.metrics.dp(3)
  textSize = kivy.metrics.dp(15)
  font_size="12dp"
  types = [int, float, str, list, imageType, soundType]
  typeNames = ["Int", "Float", "String", "List", "Image", "Sound"]
  defaultValues = [0, 0.0, "", [], defaultImage, defaultSound]
    
  # properties must be namedtuple
  def __init__(self, schemaFile = ""):
    self.oldTouchPrev = None
    self.dirty = False
    if os.path.exists(schemaFile):
      # TODO - load property file
      self.schema = None
      self.properties = []
    else:
      schema = namedtuple("schema", [])
      self.schema = schema()
      self.properties = [self.schema, ]
    self.fields = list(self.schema._fields)
    self.lastFieldNameLabel = None
    self.lastInputField = None
    self.currentIndex = 0
    # user data
    #self.lastInputField.name = fieldName # fieldname
    #self.lastInputField.lastText = "" # last value for rollback
      
    # property input filed
    #getattr(self, fieldName)
    #getattr(self, fieldName + "_icon") - resource icon object
    #getattr(self, self.lastInputField.name + "_resource_viewer") - resource viewer button
    #getattr(self, fieldName + "_type") - value of dataType
    #getattr(self, fieldName + "_type_change") - type change button
      
    # layout
    self.popup = Popup(title="Create Actor", size_hint=(1, 1), autodismiss=False)
    layout = BoxLayout(orientation="vertical", size_hint=(1,1))
    scroll = ScrollView(size_hint=(1,1))   
    self.anchorLayout = AnchorLayout(anchor_x="left", anchor_y="top", size_hint=(1,None))
    self.fieldLayout = BoxLayout(orientation="vertical", size_hint=(1, None))
    self.anchorLayout.add_widget(self.fieldLayout)
    scroll.add_widget(self.anchorLayout)
    layout.add_widget(scroll)
    self.popup.content = layout
    
    # dropdown - type change
    self.dropDown = DropDown(autodismiss=True, font_size=self.font_size, font_name=defaultFont, size_hint=(None, None), size=(self.textSize*8, self.labelHeight))
    self.dropDown.opened = False 
    def setDropDownOpened(opened):
      self.dropDown.opened = opened
    self.dropDown.bind(on_dismiss=lambda x:setDropDownOpened(False))
    for i, typeName in enumerate(self.typeNames):
      btn = Button(text=typeName, size_hint=(1,None), height=self.labelHeight, background_color=(0.2, 0.2, 0.2, 1.0))
      # type changed
      def typeChange(inst):
        self.dropDown.dismiss()
        typeIndex = self.typeNames.index(inst.text)
        dataType = self.types[typeIndex]
        value = self.defaultValues[typeIndex]
        try:
          # try to convert data type
          if dataType not in resourceTypes:
            value = dataType(self.lastInputField.text)
        except:
          log("Failed to convert data type. will use default value of the type.") 
        self.setDataType(self.lastInputField, self.types[typeIndex], value)
      btn.bind(on_release=typeChange)
      self.dropDown.add_widget(btn)
    
    # build field
    for fieldName in schema._fields:
      self.addProperty(fieldName, getattr(properties, fieldName))
      
    # add field button
    btn = Button(text="Add Property", font_size=self.font_size, size_hint_y=None, height=self.labelHeight)
    btn.bind(on_release=lambda x:self.addProperty("new", 0))
    layout.add_widget(btn)
    
    # close button
    btn = Button(text="close", font_size=self.font_size, size_hint_y=None, height=self.labelHeight)
    btn.bind(on_release=lambda x:self.close())
    layout.add_widget(btn)
    
  def addProperty(self, fieldName, properties):
      # check exist filed
      if fieldName in self.fields:
        newFieldName = fieldName
        i = 1
        while newFieldName in self.fields:
          newFieldName = "%s_%02d" % (fieldName, i)
          i += 1
        fieldName = newFieldName
      # add field
      self.fields.append(fieldName)
      # a raw layout
      raw = BoxLayout(size_hint=(1, None), height=self.labelHeight)
      self.fieldLayout.add_widget(raw)
      # field name
      filedNameWidget = TextInput(text=fieldName, font_size=self.font_size, font_name=defaultFont, multiline=False, size_hint=(None,1), width=self.labelWidth)
      filedNameWidget.bind(focus=self.focusFieldNameLabel, on_text_validate=self.validateFieldNameLabel)
      raw.add_widget(filedNameWidget)
      # data input field
      inputField = TextInput(size_hint=(1,1), font_size=self.font_size, font_name=defaultFont, multiline=False)
      # user data
      inputField.name = fieldName # fieldname
      inputField.lastText = "" # last value for rollback
      inputField.bind(focus=self.focusInputField, on_text_validate=self.validateInputField)
      inputFieldLayout = BoxLayout(size_hint=(2,1))
      inputFieldLayout.add_widget(inputField)
      raw.add_widget(inputFieldLayout)
      # set attributes
      setattr(self, fieldName, inputField)
      setattr(self, fieldName + "_icon", None) 
      setattr(self, fieldName + "_resource_viewer", None)
      setattr(self, fieldName + "_type", None)
      setattr(self, fieldName + "_type_change", None)
        
      # dataType change button
      btn = Button(text="Type", size_hint_x=None, width=self.textSize*8)
      # choose data type
      def openDataType(inst):
        self.lastInputField = inst.inputField
        self.dropDown.open(inst)
        self.dropDown.opened = True
      btn.bind(on_release=openDataType)
      btn.inputField = inputField
      # set reference data tyle button
      setattr(self, fieldName + "_type_change", btn)
      raw.add_widget(btn)
      # remove property button
      btn = Button(text="X", font_name=defaultFont, font_size=self.font_size, size_hint_x=None, width=self.textSize*2)
      btn.bind(on_release=self.removeProperty)
      btn.fieldName = fieldName
      btn.inputField = inputField
      btn.layout = raw
      raw.add_widget(btn)
      # default property type is float
      self.setDataType(inputField, float, 0.0)
        
      # refresh layout height
      self.anchorLayout.height += self.labelHeight
      self.fieldLayout.height = self.anchorLayout.height
  
  def removeProperty(self, btnInstance):
    self.fields.remove(btnInstance.fieldName)
    layout = btnInstance.layout
    layout.parent.remove_widget(layout)
    # refresh layout height
    self.anchorLayout.height -= self.labelHeight
    self.fieldLayout.height = self.anchorLayout.height
  
  def setDataType(self, inputField, dataType, value):
    # set data type
    fieldName = inputField.name
    setattr(self, fieldName + "_type", dataType)
    if dataType in resourceTypes:
      # resource data type
      inputField.text = value.resource.name
      inputField.lastText = inputField.text
      self.validateInputField(inputField)
    else:
      # general data type
      inputField.text = str(value)
      inputField.lastText = inputField.text
      # remove icon
      self.removeResourceIcon(inputField.name)
    # set data type name on button widget
    typeIndex = self.types.index(dataType)
    dataTypeBtn = getattr(self, inputField.name + "_type_change")
    dataTypeBtn.text = self.typeNames[typeIndex]
  
  def removeResourceIcon(self, fieldName):
    # remove icon
    if hasattr(self, fieldName + "_icon"):
        icon = getattr(self, fieldName + "_icon")
        if icon and icon.parent:
          icon.parent.remove_widget(icon)
        setattr(self, fieldName + "_icon", None)
    # remove resource viewer button
    if hasattr(self, fieldName + "_resource_viewer"):
        btn = getattr(self, fieldName + "_resource_viewer")
        if btn and btn.parent:
          btn.parent.remove_widget(btn)
        setattr(self, fieldName + "_resource_viewer", None)
 
  def editProperty(self, propIndex = 0):
    self.oldTouchPrev = gMyRoot.getTouchPrev()
    gMyRoot.setTouchPrev(self.touchPrev)
    # build field - set value, dataType
    self.currentIndex = propIndex
    properties = self.properties[propIndex]
    for field in properties._fields:
      value = getattr(properties, field)
      dataType = type(value)
      inputField = getattr(self, field)
      self.setDataType(inputField, dataType, value)
    self.popup.open()
    
  def close(self):
    gMyRoot.setTouchPrev(self.oldTouchPrev)
    self.popup.dismiss()
    self.dropDown.dismiss()
    # save schema
    newData = {}
    # build field
    for field in self.properties[self.currentIndex]._fields:
      try:
        fieldInput = getattr(self, field)
        newData[field] = fieldInput.dataType(fieldInput.text)
      except:
        log("Wrong type, set to default value")
        # set default data
        newData[field] = getattr(self.properties, field)
    # set new schema
    schema = namedtuple("schema", newData.keys())
    self.schema = schema(**newData)
    self.properties[self.currentIndex] = self.schema

    
  def openResourceviewer(self, instance):
    self.lastInputField = instance.inputField
    self.popup.dismiss()
    resourceViewer.openWidget(self.recvResourceName)
    
  def focusFieldNameLabel(self, fieldNameLabel, focus):
    if focus:
      self.lastFieldNameLabel = fieldNameLabel
    else:
      self.validateFieldNameLabel(fieldNameLabel)
      
  def validateFieldNameLabel(self, fieldNameLabel):
    pass
    
  def focusInputField(self, inputField, focus):
    if focus:
      self.lastInputField = inputField
    else:
      self.validateInputField(inputField)
      
  def validateInputField(self, inputField):  
    if inputField.text == None:
      inputField.text = ""
      
    self.lastInputField = inputField
    dataType = getattr(self, inputField.name + "_type")
    # check resource type
    if dataType in resourceTypes:
      resource = gResMgr.getResource(inputField.text)
      if resource:
        if dataType == imageType:
          self.recvResourceName(resource.getImage())
        elif dataType == soundType:
          self.recvResourceName(resource.getSound())
        # backup current value
        inputField.lastText = inputField.text
      else:
        # rollback
        inputField.text = inputField.lastText
    # general data type - int, float....
    else:
      typeIndex = self.types.index(dataType)
      value = self.defaultValues[typeIndex]
      try:
        # try to convert data type
        value = dataType(self.lastInputField.text)
        # backup current value
        inputField.lastText = inputField.text
      except:
        log("Wrong type inputed.")
        # rollback
        inputField.text = inputField.lastText
        
  def recvResourceName(self, resource):
    self.popup.open()
    dataType = getattr(self, self.lastInputField.name + "_type")
    if type(resource) == dataType:
      self.lastInputField.text = resource.name
      self.lastInputField.lastText = self.lastInputField.text
      
      # remove icon and resource viewer button
      self.removeResourceIcon( self.lastInputField.name )
      
      # add icon
      icon = ResourceImage(resource=resource, size_hint=(None,None))
      setattr(self, self.lastInputField.name + "_icon", icon)
      self.lastInputField.parent.add_widget(icon)
        
      # btn - open resource viewer
      btn = Button(text="...", font_size=self.font_size, font_name=defaultFont, size_hint_x=None, width=self.textSize*3)
      btn.inputField = self.lastInputField
      btn.bind(on_release = self.openResourceviewer)
      setattr(self, self.lastInputField.name + "_resource_viewer", btn)
      self.lastInputField.parent.add_widget(btn)
    
  def touchPrev(self):
    if self.dropDown.opened:
      self.dropDown.dismiss()
    elif self.lastFieldNameLabel and self.lastFieldNameLabel.focus:
      self.lastFieldNameLabel.focus = False
    elif self.lastInputField and self.lastInputField.focus:
      self.lastInputField.focus = False
    else:
      self.close()