from Utility import *
from Sprite import Sprite, gSpriteMgr
from Particle import gFxMgr
from ResourceMgr import gResMgr


class CharacterMgr(Singleton):
  self.characterList = []
  self.player = None
  
  def reset(self):
    self.characterList = []
  
  def addCharacter(self, character):
    self.characterList.append(character)
  
  def update(self):
    for character in self.characterList:
      character.update()

  
class BaseCharacter():
  def __init__(self):
    
  def update(self):
    pass
    
  def reset(self):
    pass

 
class Player(BaseCharacter, Singleton):
  pass


gCharacterMgr = CharacterMgr.instance()
gPlayer = Player()