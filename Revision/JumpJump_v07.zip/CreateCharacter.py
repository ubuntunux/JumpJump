from Utility import *
from FileBrowser import FileBrowser
from ResourceMgr import resourceViewer

class CreateCharacterWidget(Singleton):
  def __init__(self):
    self.screen = Screen(name="Create character")
    self.oldScreen = None
    self.callback_on_closed = None
    self.oldTouchPrev = None
    btn_open = Button(text="open")
    btn_save = Button(text="save")
    btn_close = Button(text="close")
    btn_resViewer = Button(text="resource viewer")
    btn_resViewer.bind(on_release=lambda x:resourceViewer.openWidget())
    btn_open.bind(on_release=lambda x:self.fileBrowser.showOpenLayout(self))
    btn_save.bind(on_release=lambda x:self.fileBrowser.showSaveAsLayout(self))
    btn_close.bind(on_release=lambda x:self.closeWidget())
    self.layout = BoxLayout(orientation="vertical", size_hint=(0.8, 0.4))
    self.layout.pos = sub(cXY, (W*0.4, H*0.2))
    self.layout.add_widget(btn_resViewer)
    self.layout.add_widget(btn_open)
    self.layout.add_widget(btn_save)
    self.layout.add_widget(btn_close)
    self.screen.add_widget(self.layout)
    gMyRoot.add_screen(self.screen)
    
    self.fileBrowser = FileBrowser.instance()
    
  def callback_open_file(self, filename):
    pass
    
  def callback_save_as(self, filename):
    pass
    
  def callback_filebrowser_closed(self):
    pass
    
  def openWidget(self, callback_on_closed = None):
    self.callback_on_closed = callback_on_closed
    gMyRoot.setTouchPrev(self.closeWidget)
    gMyRoot.current_screen(self.screen)
    
  def closeWidget(self):
    gMyRoot.remove_screen(self.screen)
    if self.callback_on_closed:
      self.callback_on_closed()
    
    