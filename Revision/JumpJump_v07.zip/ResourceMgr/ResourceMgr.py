import os

import Utility as Util
from Utility import *

class Resource:
 def __init__(self, key):
  self.key = key
  self.tag = []
  self.image = None
  self.sound = None
  
 def addTag(self, tag):
   if not self.isTag(tag):
     self.tag.append(tag)
     self.tag.sort()
 
 def isTag(self, tag):
    if type(tag) == tuple or type(tag) == list:
      for i in tag:
        if i in self.tag:
          return True
      return False
    else:
      return tag in self.tag

 def setImage(self, img):
  self.image = img

 def setSound(self, snd):
  self.sound = snd

 def getName(self):
  return self.key
  
 def getTags(self):
   return self.tag
  
 def getImage(self):
  return self.image
    
 def getTexture(self):
  return self.image.texture

 def getSound(self):
  return self.sound

 def playSound(self, loop=False):
  if self.sound:
   self.loop = loop
   self.sound.play()
   
 def stopSound(self):
  if self.sound:
   self.sound.stop()


class ResourceMgr(Singleton):
 inited = False
 tags = {}
 resources = {}
 images = {}
 sounds = {}
 def __init__(self):
   if self.inited:
     return
   self.inited = True
   ignoredir = os.path.join(os.path.abspath('.'), '.kivy')
  
   # write resource list
   with open('resources_log.txt','w') as f:
     for dirname, dirnames, filenames in os.walk('.'):
       if os.path.abspath(dirname)[:len(ignoredir)] == ignoredir:
         continue
       for filename in filenames:
         ext = os.path.splitext(filename)[1].lower()
         key = os.path.splitext(filename)[0].lower()
         filepath = os.path.join(dirname, filename)
         res = self.resources[key] if key in self.resources else Resource(key)
         if ext in ['.png','.jpg']:
           res.setImage(Image(source = filepath))
           res.addTag('image')
           self.regist_tag('image', res)
           self.images[key] = res
         elif ext in ['.wav', '.ogg']:
           res.setSound(SoundLoader.load(filepath))
           res.addTag('sound')
           self.regist_tag('sound', res)
           self.sounds[key] = res
         else:
           continue 
         for tag in filepath.split(os.sep)[1:-1]:
           tag = tag.lower()
           res.addTag(tag)
           self.regist_tag(tag, res)
         self.resources[key] = res
         # write resource list
         f.write(filepath+'\n')
            
 def getTagList(self):
   return self.tags.keys()

 def regist_tag(self, tag, resource):
   if tag not in self.tags:
     self.tags[tag] = [resource]
   elif resource not in self.tags[tag]:
     self.tags[tag].append(resource)
     
 def getResourceByTag(self, *tags):
   result = set()
   for tag in tags:
     if tag in self.tags:
       if result:
         result &= set(self.tags[tag])
       else:
         result = set(self.tags[tag])
     else:
       return []
   return list(result)
   
 def getCount(self):
  return len(self.resources)
 
 def getResourceNames(self):
   return self.resources.keys()
    
 def getResourceList(self):
   return self.resources.values()
 
 def getImageNames(self):
   return self.images.keys()
   
 def getImageList(self):
   return self.images.values()
 
 def getSoundNames(self):
   return self.sounds.keys()
   
 def getSoundList(self):
   return self.sounds.values()
   
 def getResource(self, name = ''):
   return self.resources[name] if name in self.resources else None
  
 def getResource_Rnd(self):
  return random.choice(self.resources.values())

 def getImage(self, name=''):
  return self.images[name].getImage() if name in self.images else None

 def getRandomImage(self):
  return random.choice(self.images.values()).getImage()

 def getTexture(self , name=''):
  return self.images[name].getTexture() if name in self.images else None

 def getRandomTexture(self):
  return random.choice(self.images.values()).getTexture()

 def getSound(self , name=''):
  return self.sounds[name].getSound() if name in self.sounds else None

 def getRandomSound(self):
  return random.choice(self.sounds.values()).getSound()
 
 def playSound(self, name='', loop=False):
  snd = self.getSound(name)
  if snd:
    snd.loop=loop
    snd.play()
    
 def stopSound(self, name=''):
  snd = self.getSound(name)
  if snd:
    snd.stop()

 def playRandomSound(self):
  snd = self.getRandomSound()
  if snd:
    snd.play()


class ResourceItem(BoxLayout):
  iconSizeHintX = 0.15
  labelSizeHintX = 1.0 - iconSizeHintX
  labelHeight = kivy.metrics.dp(25)
  labelPadding = 0#kivy.metrics.dp(1)
  layoutHeight = labelHeight * 5
  lineHeight = kivy.metrics.dp(2)
  gb = float(2 ** 30)
  mb = float(2 ** 20)
  kb = float(2 ** 10)
  
  def __init__(self, resource, linePos, *args, **kargs):
    BoxLayout.__init__(self, orientation="horizontal", height=self.layoutHeight, *args, **kargs)
    self.isTouched = False
    self.name = resource.getName()
    self.image = None
    self.oldTouchPrev = None

    # add layout
    self.iconLayout = BoxLayout(orientation="vertical", size_hint=(self.iconSizeHintX, 1))
    self.add_widget(self.iconLayout)
    self.infoLayout = BoxLayout(orientation="vertical", size_hint=(self.labelSizeHintX, 1))
    # add button
    self.item_btn = Button(text="Name : "+self.name, background_color=(1.0, 0.8, 0.6, 5.0), size_hint=(1, None), height=self.labelHeight)
    self.item_btn.bind(on_release=self.on_touch_do)
    self.infoLayout.add_widget(self.item_btn)
    
    # add resouce info
    labelItems = ["Tags : " + ", ".join(resource.getTags()), ]
    for item in labelItems:
      label = Label(text=item, font_size="15dp", size_hint=(1, None), size=(self.width*self.labelSizeHintX, self.labelHeight), shorten=True, shorten_from="right", halign="left", padding=(self.labelPadding, 0))
      label.text_size=(label.width, self.labelHeight)
      self.infoLayout.add_widget(label)  
    self.add_widget(self.infoLayout)
    # draw line
    with self.canvas:
      Color(1,1,1,0.5)
      Rectangle(size=(W, self.lineHeight), pos=(0, linePos-self.lineHeight))
      
  def getFileSize(self, filename):
    if os.path.exists(filename):
      size = os.path.getsize(filename)
      if size > self.gb:
        return "%.1fGb" % (size / self.gb)
      elif size > self.mb:
        return "%.1fMb" % (size / self.mb)
      elif size > self.kb:
        return "%.1fKb" % (size / self.kb)
      else:
        return "%dByte" % size
    else:
      return ""
      
  def on_touch_down(self, touch):
    if self.item_btn.collide_point(*touch.pos):
      self.on_touch_do()
      return
    elif self.collide_point(*touch.pos) and not touch.grab_current and not self.isTouched:
      touch.grab_current = self
      self.isTouched = True
      
  def on_touch_move(self, touch):
    if touch.grab_current is self:
      self.isTouched = False
      touch.ungrab(self)
  
  def on_touch_up(self, touch):
    if touch.grab_current is self:
      self.isTouched = False
      touch.ungrab(self)
      
  def on_touch_do(self, *args):
    self.oldTouchPrev = gMyRoot.getTouchPrev()
    gMyRoot.setTouchPrev(self.touchPrev)
    self.layout = Button(background_color=(0,0,0,0.7), size_hint=(None,None), size=WH)
    self.layout.bind(on_release=self.touchPrev)
    size = min(W, H) * 0.5
    img_size=(size,size) 
    scatter=Scatter(size=img_size, pos=sub(cXY, mul(img_size, 0.5)))
    scatter.add_widget(Image(source=self.image.source, size=img_size, allow_stretch=True))
    self.layout.add_widget(scatter)
    resourceViewer.screen.add_widget(self.layout)

  def touchPrev(self, *args):
    gMyRoot.setTouchPrev(self.oldTouchPrev)
    resourceViewer.screen.remove_widget(self.layout)
    
    
class ImageItem(ResourceItem):
  def __init__(self, resource, linePos, *args, **kargs):
    ResourceItem.__init__(self, resource, linePos, *args, **kargs)
    self.image = resource.getImage()
    # add icon
    self.iconLayout.add_widget(Image(texture=self.image.texture, size_hint=(1, 1)))  
    # add image info
    labelItems = ("Source : " + self.image.source, "Size : " + str(self.image.texture_size), "FileSize : " + self.getFileSize(self.image.source))
    for item in labelItems:
      label = Label(text=item, font_size="15dp", size_hint=(1, None), size=(self.width*self.labelSizeHintX, self.labelHeight), shorten=True, shorten_from="right", halign="left", padding=(self.labelPadding, 0))
      label.text_size=(label.width, self.labelHeight)
      self.infoLayout.add_widget(label)
 
    
class SoundItem(ResourceItem):
  def __init__(self, resource, linePos, *args, **kargs):
    ResourceItem.__init__(self, resource, linePos, *args, **kargs)
    self.sound = resource.getSound()
    self.image = gResMgr.getImage("speaker_icon")
    # add icon
    self.iconLayout.add_widget(Image(texture=self.image.texture, size_hint=(0.5, 0.5)))  
    # add sound info
    labelItems = ("Source : " + self.sound.source, "Length : " + str(self.sound.length), "FileSize : " + self.getFileSize(self.sound.source))
    for item in labelItems:
      label = Label(text=item, font_size="15dp", size_hint=(1, None), size=(self.width*self.labelSizeHintX, self.labelHeight), shorten=True, shorten_from="right", halign="left", padding=(self.labelPadding, 0))
      label.text_size=(label.width, self.labelHeight)
      self.infoLayout.add_widget(label)
    self.item_btn.text="Play"

  def on_touch_do(self, *args):
    super(SoundItem, self).on_touch_do()
    if self.sound.state == "play":
      self.sound.stop()
    else:
      self.sound.play()
      
  def touchPrev(self, *args):
    super(SoundItem, self).touchPrev()
    if self.sound.state == "play":
      self.sound.stop()
   
   
class ResourceViewer(Singleton):
  def __init__(self):
    self.resMgr = None
    self.screen = None
    self.oldTouchPrev = None
    self.oldScreen = None
    self.inited = False
    
  def init(self):
    self.resMgr = ResourceMgr.instance()
    self.screen = Screen(name="Resource Viewer")
    self.oldTouchPrev = None
    self.oldScreen = None
    layout = BoxLayout(orientation="vertical", size=WH)
    scroll = ScrollView(size_hint=(1,1))
    resLayout = BoxLayout(orientation="vertical", size_hint=(1, None))
    resLayoutHeight = 0
    resourceNames = self.resMgr.getResourceNames()
    resourceNames.sort()
    for resName in resourceNames:
      resource = self.resMgr.getResource(resName)
      if resource.getImage():
        item = ImageItem(resource, resLayoutHeight, size_hint=(None,None), width=W) 
        resLayoutHeight += item.height
        resLayout.add_widget(item)
      if resource.getSound():
        item = SoundItem(resource, resLayoutHeight, size_hint=(None,None), width=W) 
        resLayoutHeight += item.height
        resLayout.add_widget(item)
    resLayout.height = resLayoutHeight
    
    scroll.add_widget(resLayout)
    layout.add_widget(scroll)
    self.screen.add_widget(layout)
    self.inited = True
    
  def openWidget(self):
    if not self.inited:
      self.init()
    self.oldTouchPrev = gMyRoot.getTouchPrev()
    self.oldScreen = gMyRoot.get_current_screen()
    gMyRoot.setTouchPrev(self.closeWidget)
    gMyRoot.current_screen(self.screen)
    
  def closeWidget(self):
    gMyRoot.setTouchPrev(self.oldTouchPrev)
    gMyRoot.remove_screen(self.screen)
    if self.oldScreen:
      gMyRoot.current_screen(self.oldScreen)


#---------------------#
# set global instance
#---------------------#
gResMgr = ResourceMgr.instance()
resourceViewer = ResourceViewer.instance()