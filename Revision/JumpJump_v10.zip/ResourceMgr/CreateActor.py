from collections import namedtuple
import os, glob

from Utility import *
from FileBrowser import FileBrowser
from ResourceMgr import *
from .ActorProperty import ActorProperty

class CreateActorWidget(Singleton):
  def __init__(self):
    self.screen = Screen(name="Create Actor Property")
    self.oldScreen = None
    self.callback_on_closed = None
    self.oldTouchPrev = None
    self.propButtons = []
    
    self.layout = BoxLayout(orientation="vertical", size_hint=(0.8, 0.4))
    self.layout.pos = sub(cXY, (W*0.4, H*0.2))
    self.scrollView = ScrollView(size_hint=(1,1))
    self.layout.add_widget(self.scrollView)
    self.menu_layout = BoxLayout(orientation="vertical", size_hint=(1, None))
    self.scrollView.add_widget(self.menu_layout)
    
    btn_new = Button(text="New property")
    btn_new.bind(on_release=self.newProperty)
    self.menu_layout.add_widget(btn_new)
      
    self.screen.add_widget(self.layout)
    gMyRoot.add_screen(self.screen)
    
    self.fileBrowser = FileBrowser.instance()
    self.refresh()
    
  def refresh(self):
    for propBtton in self.propButtons:
      propBtton.parent.remove_widget(propBtton)
    self.propButtons = []
    
    for name in gResMgr.getPropertyNames():
      btn_prop = Button(text=name)
      self.propButtons.append(btn_prop)
      def openProperty(btn):
        prop = gResMgr.getProperty(btn.text)
        prop.open(self.refresh)
      btn_prop.bind(on_release=openProperty)
      self.menu_layout.add_widget(btn_prop) 
    self.menu_layout.height = len(self.menu_layout.children) * 100
    
  def newProperty(self, btn):
    prop = gResMgr.newProperty()
    prop.open(self.refresh)
      
  def openWidget(self, callback_on_closed = None):
    self.callback_on_closed = callback_on_closed
    gMyRoot.setTouchPrev(self.closeWidget)
    gMyRoot.current_screen(self.screen)
    
  def closeWidget(self):
    gMyRoot.remove_screen(self.screen)
    if self.callback_on_closed:
      self.callback_on_closed()
    
    